require 'rspec'
require_relative '../sudoku'
require_relative '../board'
require_relative '../cell'